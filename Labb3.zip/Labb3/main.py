import modules
import requests
import json

menu_choice = 0
while menu_choice != 6:
    try:
        print("-------------------------------------------------------"
              "\nVad vill du göra?"
              "\n1. Söka efter film med exakt titel "
              "\n2. Söka efter film baserat på ett ord i titeln"
              "\n3. Visa dina senaste 5 sökningar"
              "\n4. Sätta betyg på en film"
              "\n5. Skriva ut betyg på de filmer du betygsatt"
              "\n6. Avsluta programmet"
              "\n-----------------------------------------------------")
        menu_choice = int(input("Skriv in ditt val här: "))
        match menu_choice:
            case 1:
                search_title = input("Skriv in din sökning: ")
                modules.title_search(search_title)
                input("Tryck på valfri tangent för att fortsätta programmet.")
            case 2:
                search_word = input("Skriv in din sökning: ")
                modules.word_search(search_word)
                input("Tryck på valfri tangent för att fortsätta programmet.")
            case 3:
                modules.search_history(" ", 2)
                input("Tryck på valfri tangent för att fortsätta programmet.")
            case 4:
                movie_title = input("Vilken film vill du sätta betyg på? ")
                modules.rate_movie(movie_title)
                input("Tryck på valfri tangent för att fortsätta programmet.")
            case 5:
                modules.print_rating()
                input("Tryck på valfri tangent för att fortsätta programmet.")
            case 6:
                print("Programmet avslutas.")
                pass
            case default:
                print("Felaktig inmatning, mata in ett tal mellan 1-6")
                input("Tryck på valfri tangent för att fortsätta programmet.")
    except ValueError:
        print("Felaktig inmatning. Mata in ett tal mellan 1-6.")
        input("Tryck på valfri tangent för att fortsätta programmet.")