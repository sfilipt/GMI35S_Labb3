import requests
import json


def title_search(title):
    try:
        try:
            file = open("apikey.txt", "r")
            api = file.read()
            file.close()
        except FileNotFoundError:
            print("Filen apikey.txt hittades inte.")
        search_url = "https://www.omdbapi.com/?i=tt3896198&apikey=" + api + "&t=" + title
        get_movie(search_url)
        with open("search.json", "r") as file:
            json_data = json.load(file)
            print("Din sökning gav följande resultat: \n")
            print("Titel:" + json_data["Title"])
            print("Årtal: " + json_data["Year"])
            print("Genre: " + json_data["Genre"])
            print("Regissör: " + json_data["Director"] + "\n")
            search_history(str(json_data["Title"]), 1)
    except KeyError:
        print("Sökningen gav inga resultat.")


def word_search(word):
    file = open("apikey.txt", "r")
    api = file.read()
    search_url = "https://www.omdbapi.com/?i=tt3896198&apikey=" + api + "&s=" + word
    get_movie(search_url)
    try:
        with open("search.json", "r") as file:
            try:
                json_data = json.load(file)
                search_results = json_data["Search"]
                x = 0
                for filmer in search_results:
                    x = x + 1
                print("Din sökning gav " + str(x) + " träffar.")
                y = 1
                for filmer in search_results:
                    print(str(y) + ". " + filmer["Title"])
                    y = y + 1
                while True:
                    try:
                        user_choice = int(
                            input("Vilken film vill du veta mer om? Ange vilken film genom att "
                                  "ange en siffra mellan 1 och "
                                  + str(x) + ": "))
                        while user_choice > x | user_choice < 1:
                            user_choice = int(input("Du angav inte en giltig siffra, "
                                                    "ange en siffra mellan 1 och " + str(x)))
                        break
                    except ValueError:
                        print("Du angav inte en giltig siffra, ange en siffra mellan 1 och " + str(x))
                user_choice = user_choice - 1
                search_title = search_results[user_choice]["Title"]
                title_search(search_title)
            except KeyError:
                print("Sökningen gav inga resultat.")
    except FileNotFoundError:
        print("JSON filen search.json hittades inte.")


def search_history(search_title, function):
    match function:
        case 1:
            try:
                with open("searches.txt", "a") as search:
                    search.write("\n"+str(search_title))
            except FileNotFoundError:
                print("Filen searches.txt hittades inte.")
        case 2:
            try:
                with open("searches.txt", "r") as file:
                    searches = file.readlines()
                    search_amount = (len(searches))
                    for i, movie in enumerate(searches[-5:], 1):
                        print(i, movie)
                    try:
                        user_choice = int(input("Vilken film vill du veta mer om? Ange ditt val här: "))
                        match user_choice:
                            case 1:
                                if search_amount >= 5:
                                    title_search(searches[-5])
                                else:
                                    title_search(searches[-search_amount])
                            case 2:
                                if search_amount >= 4:
                                    title_search(searches[-4])
                                else:
                                    title_search(searches[-search_amount-2])
                            case 3:
                                if search_amount >= 3:
                                    title_search(searches[-3])
                                else:
                                    title_search(searches[-search_amount-3])
                            case 4:
                                if search_amount >= 2:
                                    title_search(searches[-2])
                                else:
                                    title_search(searches[-search_amount - 4])
                            case 5:
                                if search_amount >= 1:
                                    title_search(searches[-1])
                                else:
                                    title_search(searches[-search_amount - 5])
                            case default:
                                print("Du måste skriva in ett tal mellan 1 och 5. Du tas nu tillbaka till "
                                      "huvudmenyn.")
                    except (ValueError, IndexError):
                        print("Du måste skriva in ett tal mellan 1 och 5, talet måste finnas med i listan. "
                              "Du tas nu tillbaka till huvudmenyn.")
            except FileNotFoundError:
                print("Filen searches.txt hittades inte.")


def get_movie(url):
    response = requests.get(url)
    json_data_obj = response.json()
    try:
        with open("search.json", "w") as file:
            json.dump(json_data_obj, file, ensure_ascii= False , indent= 4)
    except FileNotFoundError:
        print("JSON-filen search.json hittades inte.")


def rate_movie(title):
    try:
        file = open("apikey.txt", "r")
        api = file.read()
        file.close()
    except FileNotFoundError:
        print("Filen apikey.txt hittades inte.")
    search_url = "https://www.omdbapi.com/?i=tt3896198&apikey=" + api + "&t=" + title
    get_movie(search_url)
    try:
        with open("search.json", "r") as file:
            json_data = json.load(file)
            print("Du valde: " + json_data["Title"] + " som släpptes " + json_data["Year"] + ".")
            user_choice = input("Stämmer detta? J/N: ")
            user_choice.lower()
            match user_choice:
                case "j":
                    while True:
                        try:
                            user_rating = int(input("Vilket betyg vill du sätta på " + json_data["Title"] + "? "
                                                    "Ange ett tal mellan 1 och 10: "))
                            if 1 <= user_rating <= 10:
                                break
                            else:
                                print("Felaktig inmatning, ange ett tal mellan 1 och 10.")
                        except ValueError:
                            print("Ange ett tal mellan 1 och 10.")
                    rating_dict = {json_data["Title"]: str(user_rating)}
                    with open("movie_rating.json", "r") as rating_file:
                        try:
                            json_readobj = json.load(rating_file)
                            rating_dict.update(json_readobj)
                        except json.decoder.JSONDecodeError:
                            pass
                    with open("movie_rating.json", "w") as dump_file:
                        json.dump(rating_dict, dump_file, ensure_ascii=False, indent=4)
                    print("Du gav " + json_data["Title"] + " betyget " + str(user_rating))
                case "n":
                    print("Du tas nu tillbaka till huvudmenyn.")
                    pass
                case default:
                    print("Felaktig inmatning. Du tas nu tillbaka till huvudmenyn.")
                    pass
    except FileNotFoundError:
        print("JSON-filen search.json hittades inte.")


def print_rating():
    rating_dict = {}
    try:
        with open("movie_rating.json", "r") as file:
            json_data = json.load(file)
            rating_dict.update(json_data)
            for key in rating_dict:
                print("Du gav " + key, "betyget: ", end="")
                for value in rating_dict[key]:
                    print(value)
    except FileNotFoundError:
        print("JSON filen movie_rating.json hittades inte.")

